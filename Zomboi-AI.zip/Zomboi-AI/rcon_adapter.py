from discord.ext import tasks, commands
from discord.ext.commands import has_permissions
import os
from rcon.source import Client, rcon
import re
from datetime import datetime


class RCONAdapter(commands.Cog):
    """Handles RCON-based server interactions."""

    def __init__(self, bot):
        self.bot = bot
        self.rconHost = os.getenv("RCON_HOST", "localhost")
        self.rconPort = int(os.getenv("RCON_PORT", 27015))
        self.rconPassword = os.getenv("RCON_PASSWORD")
        if not self.rconPassword:
            self.bot.log.warning("RCON password is not set; RCON functionality may not work.")
        self.syncplayers.start()

    @commands.command()
    @has_permissions(administrator=True)
    async def option(self, ctx, option: str, newValue: str = None):
        """
        Show or set the value of a server option.

        Parameters:
        - `option`: The server option to retrieve or modify.
        - `newValue`: If provided, sets the value for the specified option.
        """
        try:
            async with Client(self.rconHost, self.rconPort, passwd=self.rconPassword, timeout=5.0) as client:
                if newValue:
                    result = await client.run(f"changeoption {option} {newValue}")
                    await ctx.send(f"`{result}`")
                else:
                    message = await client.run("showoptions")
                    options = message.splitlines()
                    matches = [line for line in options if re.search(option, line, re.IGNORECASE)]
                    if matches:
                        formatted_options = "\n".join(matches)
                        await ctx.send(f"```\n{formatted_options}\n```")
                    else:
                        await ctx.send("No matches found for the specified option.")
        except Exception as e:
            await ctx.send("An error occurred while processing the command.")
            self.bot.log.error(f"Error in `option` command: {e}")

    @commands.command()
    @has_permissions(administrator=True)
    async def addxp(self, ctx, name: str = None, skill: str = None, amount: int = None):
        """
        Add experience points to a player.

        Parameters:
        - `name`: The player's name.
        - `skill`: The skill to add experience to.
        - `amount`: The amount of experience to add.
        """
        if not all([name, skill, amount]):
            await ctx.reply("You must provide a name, skill, and amount.")
            return
        try:
            async with Client(self.rconHost, self.rconPort, passwd=self.rconPassword, timeout=5.0) as client:
                result = await client.run(f'addxp "{name}" {skill}={amount}')
                await ctx.send(result)
        except Exception as e:
            await ctx.send("Failed to add experience points.")
            self.bot.log.error(f"Error in `addxp` command: {e}")

    @tasks.loop(minutes=5)
    async def syncplayers(self):
        """Sync online players by comparing RCON data."""
        if not self.rconPassword:
            self.bot.log.warning("RCON password not set -- unable to sync players.")
            self.syncplayers.stop()
            return

        try:
            # Fetch players from the RCON server
            response = await rcon(
                "players",
                host=self.rconHost,
                port=self.rconPort,
                passwd=self.rconPassword,
            )
            response = "\n".join(response.splitlines()[1:])  # Remove the first line of the response
            userHandler = self.bot.get_cog("UserHandler")

            # Update user states based on RCON response
            for user in userHandler.users.values():
                if user.name in response:
                    if not user.online:
                        self.bot.log.info(f"Sync: Player {user.name} is now online.")
                    user.lastSeen = datetime.now()
                    user.online = True
                else:
                    if user.online:
                        self.bot.log.info(f"Sync: Player {user.name} is now offline.")
                    user.online = False

            self.bot.log.info("Player synchronization completed successfully.")
        except Exception as e:
            self.bot.log.error(f"Error during player sync: {e}")
            self.syncplayers.stop()
