from datetime import datetime
import discord
from discord.ext import tasks, commands
from file_read_backwards import FileReadBackwards
import glob
import os


class AdminLogHandler(commands.Cog):
    """Handles printing log files to the admin channel."""

    def __init__(self, bot, logPath):
        self.bot = bot
        self.logPath = logPath
        self.lastUpdateTimestamp = datetime.now()
        self.sendLogs = os.getenv("ADMIN_LOGS", "True") == "True"
        self.adminChannel = None
        self.textChannel = None
        self.was_turned_off = False

        if not self.sendLogs:
            self.bot.log.info("Admin logs not enabled.")
            return

        # Setup admin and text channels
        self.setup_channels()
        self.bot.log.info("Admin logs enabled.")
        self.update.start()

    def setup_channels(self):
        """Configure admin and text channels based on environment variables."""
        admin_channel_env = os.getenv("ADMIN_CHANNEL")
        text_channel_env = os.getenv("CHANNEL")
        self.adminChannel = self.get_channel(admin_channel_env)
        self.textChannel = self.get_channel(text_channel_env)

    def get_channel(self, channel_identifier):
        """Retrieve a channel by ID or name."""
        if channel_identifier:
            if channel_identifier.isdigit():
                return self.bot.get_channel(int(channel_identifier))
            return discord.utils.get(self.bot.get_all_channels(), name=channel_identifier)
        return None

    def splitLine(self, line: str):
        """Split a log line into a timestamp and message."""
        timestampStr, message = line.strip()[1:].split("]", 1)
        timestamp = datetime.strptime(timestampStr, "%d-%m-%y %H:%M:%S.%f")
        return timestamp, message

    @tasks.loop(seconds=10)
    async def update(self):
        """Read and send new admin log entries."""
        try:
            files = glob.glob(self.logPath + "/*admin.txt")
            if files:
                newTimestamps = []
                for file in files:
                    with FileReadBackwards(file, encoding="utf-8") as f:
                        for line in f:
                            try:
                                timestamp, message = self.splitLine(line)
                                if "closed server." in message and not self.was_turned_off:
                                    await self.textChannel.send("Server was shutdown.")
                                    self.bot.log.info("Server closed.")
                                    self.was_turned_off = True

                                if timestamp > self.lastUpdateTimestamp:
                                    newTimestamps.append(timestamp)
                                    formatted_message = f"[{timestamp}]: {message}"
                                    if self.adminChannel:
                                        await self.adminChannel.send(formatted_message)
                                else:
                                    break
                            except UnicodeDecodeError as e:
                                self.bot.log.warning(f"Skipped a line due to decoding error: {e}")
                if newTimestamps:
                    self.lastUpdateTimestamp = max(newTimestamps)
        except Exception as e:
            self.bot.log.error(f"Error in AdminLogHandler update: {e}")
