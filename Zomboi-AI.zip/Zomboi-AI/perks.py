from datetime import datetime
from discord.ext import tasks, commands
from file_read_backwards import FileReadBackwards
import glob
import os
import re
from charset_normalizer import detect


class PerkHandler(commands.Cog):
    """Handles perk log files for tracking player events."""

    def __init__(self, bot, logPath):
        self.bot = bot
        self.logPath = logPath
        self.lastUpdateTimestamp = datetime.now()
        self.bot.loop.create_task(self.loadHistory())  # Asynchronous history loading
        self.update.start()
        self.notifyJoin = os.getenv("JOINS", "True") == "True"
        self.notifyDeath = os.getenv("DEATHS", "True") == "True"
        self.notifyPerk = os.getenv("PERKS", "True") == "True"
        self.notifyCreateChar = os.getenv("CREATECHAR", "True") == "True"

    def detect_file_encoding(self, file_path):
        """Detect the encoding of a file."""
        with open(file_path, "rb") as f:
            raw_data = f.read(4096)  # Read a small portion of the file
            result = detect(raw_data)
            return result.get("encoding", "utf-8")  # Default to UTF-8 if no encoding is detected

    async def loadHistory(self):
        """Loads historical perk data for initialization."""
        self.bot.log.info("Loading perk history...")
        try:
            files = glob.glob(self.logPath + "/**/*PerkLog.txt", recursive=True)
            files.sort(key=os.path.getmtime)
            for file in files:
                try:
                    encoding = self.detect_file_encoding(file)
                    with open(file, encoding=encoding) as f:
                        for line in f:
                            try:
                                timestamp, message = self.splitLine(line)
                                await self.handleLog(timestamp, message)
                            except Exception as line_error:
                                self.bot.log.warning(f"Error processing line in {file}: {line_error}")
                except Exception as file_error:
                    self.bot.log.error(f"Error reading file {file}: {file_error}")
            self.bot.log.info("Perk history loaded.")
        except Exception as e:
            self.bot.log.error(f"Error loading perk history: {e}")

    def splitLine(self, line: str):
        """Split a log line into a timestamp and the remaining message."""
        timestampStr, message = line.strip()[1:].split("]", 1)
        timestamp = datetime.strptime(timestampStr, "%d-%m-%y %H:%M:%S.%f")
        return timestamp, message

    async def handleLog(self, timestamp: datetime, message: str, fromUpdate=False):
        """Processes a single log line and generates notifications if needed."""
        try:
            # Ignore the ID at the start of the message
            message = message[message.find("[", 2) + 1:]

            # Extract the username
            name, message = message.split("]", 1)
            userHandler = self.bot.get_cog("UserHandler")
            user = userHandler.getUser(name)
            char_name = await userHandler.getCharName(name) if fromUpdate and user else None
            log_char_string = f"{char_name} " if char_name else ""

            # Extract position info (ignored here but kept for completeness)
            x = message[1:message.find(",")]
            y = message[message.find(",") + 1:message.find(",", message.find(",") + 1)]
            message = message[message.find("[", 2) + 1:]

            # Parse message type (e.g., "Died", "Login", "Level Changed")
            type, message = message.split("]", 1)

            if type == "Level Changed":
                # Extract perk and level
                match = re.search(r"\[(\w+)\]\[(\d+)\]", message)
                if match:
                    perk, level = match.groups()
                    user.perks[perk] = level  # Update the user's perk level
                    if timestamp > self.lastUpdateTimestamp and self.notifyPerk:
                        return f":bar_chart: {log_char_string}(**{user.name}**) has reached {perk} level {level}."

            elif type == "Died":
                # Handle player death
                hours = re.search(r"Hours Survived: (\d+)", message).group(1)
                user.hoursAlive = hours
                if int(hours) > int(user.recordHoursAlive):
                    user.recordHoursAlive = hours
                user.died.append(timestamp)
                if timestamp > self.lastUpdateTimestamp and self.notifyDeath:
                    return f":skull_crossbones: {log_char_string}(**{user.name}**) died after surviving {user.hoursAlive} hours :zombie:"

            elif type == "Login":
                # Handle player login
                hours = re.search(r"Hours Survived: (\d+)", message).group(1)
                user.hoursAlive = hours
                if int(hours) > int(user.recordHoursAlive):
                    user.recordHoursAlive = hours
                if timestamp > self.lastUpdateTimestamp and self.notifyJoin:
                    return f":parachute: {log_char_string}(**{user.name}**) has arrived, survived for {user.hoursAlive} hours."

            elif "Created Player" in type:
                # Handle new character creation
                hours = re.search(r"Hours Survived: (\d+)", message).group(1)
                user.hoursAlive = hours
                if int(hours) > int(user.recordHoursAlive):
                    user.recordHoursAlive = hours
                if timestamp > self.lastUpdateTimestamp and self.notifyCreateChar:
                    return f":bust_in_silhouette: **{user.name}** just woke up in the apocalypse..."

            else:
                # Ignore other types of messages
                pass

        except Exception as e:
            self.bot.log.error(f"Error in handleLog: {e}")

    @tasks.loop(seconds=5)
    async def update(self):
        """Reads and processes new perk log entries."""
        try:
            files = glob.glob(self.logPath + "/*PerkLog.txt")
            if files:
                with FileReadBackwards(files[0], encoding="utf-8") as f:
                    newTimestamp = self.lastUpdateTimestamp
                    for line in f:
                        try:
                            timestamp, message = self.splitLine(line)
                            if timestamp > newTimestamp:
                                newTimestamp = timestamp
                            if timestamp > self.lastUpdateTimestamp:
                                notification = await self.handleLog(timestamp, message, fromUpdate=True)
                                if notification and self.bot.channel:
                                    await self.bot.channel.send(notification)
                            else:
                                break
                        except UnicodeDecodeError as e:
                            self.bot.log.warning(f"Skipped a line due to decoding error: {e}")
                        except Exception as line_error:
                            self.bot.log.warning(f"Error processing line: {line_error}")
                    self.lastUpdateTimestamp = newTimestamp
        except Exception as e:
            self.bot.log.error(f"Error in PerkHandler update: {e}")
