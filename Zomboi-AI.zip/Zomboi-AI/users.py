from dataclasses import dataclass, field
from datetime import datetime
import discord
from discord.ext import tasks, commands
from file_read_backwards import FileReadBackwards
import glob
import os
import re
from tabulate import tabulate
from typing import List
from pathlib import Path
import aiosqlite
import asyncio
from charset_normalizer import detect

DISCORD_MAX_CHAR = 2000


@dataclass
class User:
    """A class representing a user."""
    name: str
    hoursAlive: int = 0
    recordHoursAlive: int = 0
    perks: dict = field(default_factory=lambda: dict())
    online: bool = False
    lastSeen: datetime = datetime(1, 1, 1)
    lastLocation: tuple = (0, 0)
    died: List[datetime] = field(default_factory=lambda: [])


class UserHandler(commands.Cog):
    """Handles all the info we get from the user log files."""

    def __init__(self, bot, logPath):
        self.bot = bot
        self.logPath = logPath
        self.lastUpdateTimestamp = datetime.now()
        self.users = {}
        self.notifyDisconnect = os.getenv("DISCONNECTS", "True") == "True"
        self.loadHistory()  # Load historical logs on initialization
        self.update.start()
        self.onlineCount = None

    def getUser(self, name: str):
        """Get a user from a name, will create if it doesn't exist."""
        if name not in self.users:
            self.users[name] = User(name)
        return self.users[name]

    async def getCharName(self, name: str):
        """Asynchronously finds the user's character name from the database."""
        await asyncio.sleep(5)  # Asynchronous delay instead of blocking
        try:
            playerdb = Path(os.getenv("SAVES_PATH")).joinpath("players.db") if os.getenv(
                "SAVES_PATH"
            ) else Path.home().joinpath("Zomboid/Saves/Multiplayer/pzserver").joinpath(
                "players.db"
            )
            if not playerdb.is_file():
                self.bot.log.error("Invalid Zomboid saves path.")
                return ""
            async with aiosqlite.connect(str(playerdb)) as db:  # Async SQLite
                async with db.execute(
                    "SELECT name FROM networkPlayers WHERE username = ?", [name]
                ) as cursor:
                    charName = await cursor.fetchone()
                    return charName[0] if charName else None
        except Exception as e:
            self.bot.log.error(f"Error in getCharName: {e}")
            return None

    def detect_file_encoding(self, file_path):
        """Detect the encoding of a file."""
        with open(file_path, "rb") as f:
            raw_data = f.read(4096)  # Read a small portion of the file
            result = detect(raw_data)
            return result.get("encoding", "utf-8")  # Default to UTF-8 if no encoding is detected

    def loadHistory(self):
        """Loads historical log data to initialize user state."""
        self.bot.log.info("Loading user history...")
        try:
            files = glob.glob(self.logPath + "/**/*user.txt", recursive=True)
            files.sort(key=os.path.getmtime)
            for file in files:
                try:
                    encoding = self.detect_file_encoding(file)
                    with open(file, encoding=encoding) as f:
                        for line in f:
                            try:
                                timestamp, message = self.splitLine(line)
                                self.handleLog(timestamp, message)
                            except Exception as line_error:
                                self.bot.log.warning(f"Error processing line in {file}: {line_error}")
                except Exception as file_error:
                    self.bot.log.error(f"Error reading file {file}: {file_error}")
            self.bot.log.info("User history loaded.")
        except Exception as e:
            self.bot.log.error(f"Error loading user history: {e}")

    @tasks.loop(seconds=5)
    async def update(self):
        """Update user information from log files."""
        files = glob.glob(self.logPath + "/*user.txt")
        if len(files) > 0:
            try:
                with FileReadBackwards(files[0], encoding="utf-8") as f:
                    newTimestamp = self.lastUpdateTimestamp
                    for line in f:
                        try:
                            timestamp, message = self.splitLine(line)
                            if timestamp > newTimestamp:
                                newTimestamp = timestamp
                            if timestamp > self.lastUpdateTimestamp:
                                message = self.handleLog(timestamp, message)
                                if message and self.bot.channel:
                                    await self.bot.channel.send(message)
                            else:
                                break
                        except UnicodeDecodeError as e:
                            self.bot.log.warning(f"Skipped a line due to decoding error: {e}")
                        except Exception as line_error:
                            self.bot.log.warning(f"Error processing line: {line_error}")
                    self.lastUpdateTimestamp = newTimestamp
            except Exception as e:
                self.bot.log.error(f"Error in UserHandler update: {e}")

        # Update bot activity for the number of online players.
        onlineCount = sum(1 for user in self.users.values() if user.online)
        if onlineCount != self.onlineCount:
            playerString = "nobody" if onlineCount == 0 else f"{onlineCount} survivors"
            await self.bot.change_presence(activity=discord.Game(f"PZ with {playerString}"))
            self.onlineCount = onlineCount

    def splitLine(self, line: str):
        """Split a log line into a timestamp and the remaining message."""
        timestampStr, message = line.strip()[1:].split("]", 1)
        timestamp = datetime.strptime(timestampStr, "%d-%m-%y %H:%M:%S.%f")
        return timestamp, message

    def handleLog(self, timestamp: datetime, message: str):
        """Parse the log message and store any useful info."""
        if "disconnected" in message:
            match = re.search(r'"(.*)".*\((\d+),(\d+),\d+\)', message)
            if match:
                name = match.group(1)
                user = self.getUser(name)
                user.lastSeen = timestamp
                user.lastLocation = (match.group(2), match.group(3))
                user.online = False
                self.bot.log.info(f"{name} disconnected.")
                return f":person_running: {name} has left"
        elif "fully connected" in message:
            match = re.search(r'"(.*)".*\((\d+),(\d+)', message)
            if match:
                name = match.group(1)
                user = self.getUser(name)
                user.lastSeen = timestamp
                user.lastLocation = (match.group(2), match.group(3))
                user.online = True
                self.bot.log.info(f"{name} connected.")
        return None
